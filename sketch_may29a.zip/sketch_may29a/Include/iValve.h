#ifndef IVALVE_H
#define IVALVE_H

class iValve
{
public:
	iValve();
	~iValve();
	void Open(uint8_t volume);
};

#endif