#include "Sensor.h"

Sensor::Sensor()
{

}

Sensor::~Sensor()
{
	// nothing to delete here
}

int Sensor::GetData()
{
	// TO DO: read data from sensor

	return 0;
}