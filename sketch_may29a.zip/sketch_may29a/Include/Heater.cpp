#include "Heater.h"

Heater::Heater()
{

}

Heater::~Heater()
{
	// nothing to delete here
}

void Heater::Heat()
{
	// TO DO
}