#ifndef IHEATER_H
#define IHEATER_H

class iHeater
{
public:
	~iHeater();
	void Heat();
};

#endif