#include "Valve.h"

Valve::Valve()
{
	
}

Valve::~Valve()
{
	// nothing to delete here
}

void Open(uint8_t volume)
{
	// TO DO: open valve here
}

