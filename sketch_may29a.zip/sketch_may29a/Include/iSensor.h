#ifndef iSENSOR_H
#define ISENSOR_H

class iSensor
{
public:
	~iSensor();
	int GetData();
};

#endif