#ifndef UI_H
#define UI_H

class UI
{
public:
	UI();
	~UI();
	void ShowOnScreen();
	void SendInstruction();
};

#endif