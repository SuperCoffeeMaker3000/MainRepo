#include "MQTT.h"

MQTT::MQTT()
{
	ssid = "12connect";
	mqttUser = "i339762_martijnbooij";
	mqttPass = "Rtd1Ss44uHGLNq";

	wifiStatus = WL_IDLE_STATUS;

	Client1 = new WiFiClient();

	server = new IPAddress(145, 85, 4, 91);

	mqttClient = new PubSubClient(*Client1);

	mqttClientId = "Genuino101-";
	buttonTopic = "public/i339762_martijnbooij/";
}

MQTT::~MQTT()
{
	delete Client1;
	Client1 = NULL;

	delete server;
	server = NULL;

	delete mqttClient;
	mqttClient = NULL;
}

void MQTT::Setup()
{
	uint8_t mac[6];
 	WiFi.macAddress(mac);

 	connectWifi();

 	mqttClient->setServer(server, 1883);
  	connectMqtt();

  	mqttClient->subscribe("public/i339762_martijnbooij/");

  	mqttClient->setCallback(callback);
}

void MQTT::Run()
{
	if (wifiStatus != WL_CONNECTED)
    connectWifi();

  	while (!mqttClient.connected())
    connectMqtt();

  	//mqttClient.publish((char*) buttonTopic.c_str(), "hoi");
  	mqttClient.loop();
}

void MQTT::callback(char* topic, byte* payload, unsigned int length)
{
 	char* temp;
  
  	for (int i = 0; i < length; i++)
  	{
  		temp[i] = char(payload[i]);
  	}

  	currentMessage = temp;
}

void MQTT::connectWifi()
{
  	wifiStatus = WiFi.begin(ssid);
}

void MQTT::connectMqtt()
{
	mqttClient->connect((char*) mqttClientId, mqttUser, mqttPass);
}