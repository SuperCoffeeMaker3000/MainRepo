#ifndef MQTT_H
#define MQTT_H

#include <WiFi.h>
#include <WiFiClient.h>
#include <WiFiServer.h>
#include <WiFiUdp.h>
#include <SPI.h>
#include <PubSubClient.h>

class MQTT
{
public:
	MQTT();
	~MQTT();
	void Setup();
	void Run();
	void callback(char* topic, byte* payload, unsigned int length);
	void connectWifi();
	void connectMqtt();

private:
	char* ssid;
	char* mqttUser;
	char* mqttPass;

	char* mqttClientId;
	char* buttonTopic;

	WiFiClient* Client1;

	IPAddress* server;
	PubSubClient* mqttClient;

	int wifiStatus;

	char* currentMessage;
};

#endif